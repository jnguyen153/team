Google Docs (Requirements)
https://docs.google.com/document/d/1uq0FvCTBsU_QHVjUseUc6RyQTxzBtcA-GCWXuh7Ls6k/edit?usp=sharing 


### TODO list
Zhen
    - import caldenar parser
    - output binary file
    - assembles other pages