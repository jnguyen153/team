To run


npm install

npm run dev



it should run on localhost after that


To run server for sending email use this command in separate window:

node server.js

