const Gallery = () => {
  return(
    <div>

    </div>
  )
}

export default Gallery;